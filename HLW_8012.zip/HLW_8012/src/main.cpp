#include <Arduino.h>

#define Freq_In 7
#define Mux 8
#define HWL_Sel 9

unsigned long frecuencia(void);
float tension(void);
float corriente(void);
float potencia(void);

void setup()
{
  Serial.begin(9600);
  pinMode(Freq_In, INPUT);
  pinMode(Mux, OUTPUT);
  pinMode(HWL_Sel, OUTPUT);
}

/*

Mux   0 0 0 CF (medición de potencia)
Mux   1 0 0 y HWL_sel = LOW (medicion de tension)
Mux   1 0 0 y HWL_sel = HIGH (medicion de corriente)
*/
void loop()
{

  Serial.print("Corriente: ");
  Serial.println(corriente() * 1000.0, 2);

  Serial.print("Tension: ");
  Serial.println(tension(), 2);

  Serial.print("Potencia: ");
  Serial.println(potencia() * 1000000.0, 2);
}



unsigned long frecuencia(void)
{
  unsigned long Pulse_High = pulseIn(Freq_In, HIGH);
  unsigned long frecuencia = 1 / (Pulse_High * 0.000002); // 2 / 1000000
  return frecuencia;
}

float tension(void)
{
  digitalWrite(Mux, HIGH);
  digitalWrite(HWL_Sel, LOW);
  delay(12000);
  float V = (frecuencia() * 2.43 * 512.0 * 2351.0 / (2.0 * 3579000.0)); // 2351.0 viene del divisor de tensión
  return V;
}

float corriente(void)
{
  digitalWrite(Mux, HIGH);
  digitalWrite(HWL_Sel, HIGH);
  delay(1000);
  float I = (frecuencia() * 2.43 * 512.0 / (24.0 * 3579000.0));
  digitalWrite(HWL_Sel, LOW);
  return I;
}

float potencia(void)
{
  digitalWrite(Mux, LOW);
  digitalWrite(HWL_Sel, LOW);
  delay(4000);
  float P = (frecuencia() * 5.9 * 128.0 / (48.0 * 3579000.0));  // 2.43^2 =~ 5.9
  digitalWrite(HWL_Sel, LOW);
  return P;
}